package com.cbsa.mcoe.ace.unused_activites

import android.app.Activity
import android.os.Bundle
import com.cbsa.mcoe.ace.R

class PrivacyPolicyEN : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.privacypolicyen)
    }
}